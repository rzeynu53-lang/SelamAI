package com.selamai.assistant.ui.settings

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import com.selamai.assistant.data.local.prefs.SecurePrefsManager
import com.selamai.assistant.ui.theme.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val securePrefsManager: SecurePrefsManager
) : ViewModel() {

    private val _apiKey = MutableStateFlow(securePrefsManager.getApiKey())
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _modelName = MutableStateFlow(securePrefsManager.getModelName())
    val modelName: StateFlow<String> = _modelName.asStateFlow()

    private val _systemPrompt = MutableStateFlow(securePrefsManager.getSystemPrompt())
    val systemPrompt: StateFlow<String> = _systemPrompt.asStateFlow()

    val themeMode: StateFlow<ThemeMode> = securePrefsManager.themeModeFlow
    val appLanguage: StateFlow<String> = securePrefsManager.appLanguageFlow

    fun onApiKeyChange(newKey: String) {
        _apiKey.value = newKey
    }

    fun onModelNameChange(newModel: String) {
        _modelName.value = newModel
    }

    fun onSystemPromptChange(newPrompt: String) {
        _systemPrompt.value = newPrompt
    }

    fun resetSystemPromptToDefault() {
        _systemPrompt.value = SecurePrefsManager.DEFAULT_SYSTEM_PROMPT
    }

    fun onThemeModeChange(mode: ThemeMode) {
        securePrefsManager.setThemeMode(mode)
    }

    fun onAppLanguageChange(langCode: String) {
        securePrefsManager.setAppLanguage(langCode)
        val appLocale = LocaleListCompat.forLanguageTags(langCode)
        AppCompatDelegate.setApplicationLocales(appLocale)
    }

    fun saveSettings() {
        securePrefsManager.setApiKey(_apiKey.value)
        securePrefsManager.setModelName(_modelName.value)
        securePrefsManager.setSystemPrompt(_systemPrompt.value)
    }
}
