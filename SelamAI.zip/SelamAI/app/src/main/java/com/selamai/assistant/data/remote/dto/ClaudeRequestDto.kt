package com.selamai.assistant.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ClaudeMessageRequest(
    val model: String,
    @SerialName("max_tokens")
    val maxTokens: Int = 4096,
    val system: String,
    val messages: List<ClaudeInputMessage>,
    val stream: Boolean = true
)

@Serializable
data class ClaudeInputMessage(
    val role: String, // "user" or "assistant"
    val content: List<ClaudeContentBlock>
)

@Serializable
data class ClaudeContentBlock(
    val type: String, // "text" or "image"
    val text: String? = null,
    val source: ClaudeImageSource? = null
) {
    companion object {
        fun textBlock(text: String) = ClaudeContentBlock(
            type = "text",
            text = text
        )

        fun imageBlock(mediaType: String, base64Data: String) = ClaudeContentBlock(
            type = "image",
            source = ClaudeImageSource(
                type = "base64",
                mediaType = mediaType,
                data = base64Data
            )
        )
    }
}

@Serializable
data class ClaudeImageSource(
    val type: String = "base64",
    @SerialName("media_type")
    val mediaType: String,
    val data: String
)
