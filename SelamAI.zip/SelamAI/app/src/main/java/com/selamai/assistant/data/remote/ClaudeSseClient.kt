package com.selamai.assistant.data.remote

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.selamai.assistant.data.remote.dto.ClaudeErrorResponseDto
import com.selamai.assistant.data.remote.dto.ClaudeMessageRequest
import com.selamai.assistant.data.remote.dto.ClaudeStreamEventDto
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import javax.inject.Inject
import javax.inject.Singleton

sealed class SseEvent {
    data class TokenDelta(val text: String) : SseEvent()
    data class RateLimitRetry(val attempt: Int, val waitMs: Long) : SseEvent()
    data object Completed : SseEvent()
    data class Error(val errorType: ClaudeErrorType, val message: String) : SseEvent()
}

enum class ClaudeErrorType {
    OFFLINE,
    INVALID_API_KEY,
    RATE_LIMIT,
    API_ERROR,
    NETWORK_ERROR
}

@Singleton
class ClaudeSseClient @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val json: Json
) {

    fun streamMessages(
        apiKey: String,
        requestPayload: ClaudeMessageRequest
    ): Flow<SseEvent> = flow {
        if (apiKey.isBlank()) {
            emit(
                SseEvent.Error(
                    ClaudeErrorType.INVALID_API_KEY,
                    "Anthropic API key is missing. Please enter your key in Settings."
                )
            )
            return@flow
        }

        if (!isNetworkAvailable()) {
            emit(
                SseEvent.Error(
                    ClaudeErrorType.OFFLINE,
                    "No internet connection. Please check your network and try again."
                )
            )
            return@flow
        }

        val requestJson = json.encodeToString(requestPayload)
        val mediaType = "application/json; charset=utf-8".toMediaType()

        var attempt = 0
        val maxRetries = 2
        var finished = false

        while (attempt <= maxRetries && !finished) {
            val request = Request.Builder()
                .url(ANTHROPIC_MESSAGES_URL)
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", ANTHROPIC_VERSION)
                .addHeader("content-type", "application/json")
                .addHeader("accept", "text/event-stream")
                .post(requestJson.toRequestBody(mediaType))
                .build()

            var shouldRetry429 = false
            var retryWaitMs = 2000L * (attempt + 1)

            try {
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        val code = response.code
                        val rawError = response.body?.string().orEmpty()
                        val parsedMessage = parseErrorMessage(rawError, code)

                        when (code) {
                            401, 403 -> {
                                emit(SseEvent.Error(ClaudeErrorType.INVALID_API_KEY, parsedMessage))
                                finished = true
                            }
                            429, 529 -> {
                                if (attempt < maxRetries) {
                                    val retryAfterHeader = response.header("retry-after")?.toLongOrNull()
                                    if (retryAfterHeader != null && retryAfterHeader in 1..30) {
                                        retryWaitMs = retryAfterHeader * 1000L
                                    }
                                    shouldRetry429 = true
                                } else {
                                    emit(SseEvent.Error(ClaudeErrorType.RATE_LIMIT, parsedMessage))
                                    finished = true
                                }
                            }
                            else -> {
                                emit(SseEvent.Error(ClaudeErrorType.API_ERROR, parsedMessage))
                                finished = true
                            }
                        }
                    } else {
                        val body = response.body
                        if (body == null) {
                            emit(SseEvent.Error(ClaudeErrorType.API_ERROR, "Empty response stream from Claude API."))
                            finished = true
                        } else {
                            BufferedReader(
                                InputStreamReader(body.byteStream(), StandardCharsets.UTF_8)
                            ).use { reader ->
                                var line: String?
                                while (reader.readLine().also { line = it } != null) {
                                    val currentLine = line?.trim() ?: continue
                                    if (!currentLine.startsWith("data:")) continue

                                    val dataPayload = currentLine.removePrefix("data:").trim()
                                    if (dataPayload.isEmpty() || dataPayload == "[DONE]") continue

                                    val eventDto = runCatching {
                                        json.decodeFromString<ClaudeStreamEventDto>(dataPayload)
                                    }.getOrNull() ?: continue

                                    when (eventDto.type) {
                                        "content_block_delta" -> {
                                            val deltaText = eventDto.delta?.text
                                            if (!deltaText.isNullOrEmpty()) {
                                                emit(SseEvent.TokenDelta(deltaText))
                                            }
                                        }
                                        "message_stop" -> {
                                            emit(SseEvent.Completed)
                                            finished = true
                                        }
                                        "error" -> {
                                            val errMsg = eventDto.error?.message ?: "Stream error returned by Claude."
                                            emit(SseEvent.Error(ClaudeErrorType.API_ERROR, errMsg))
                                            finished = true
                                        }
                                    }
                                }
                            }
                            if (!finished) {
                                emit(SseEvent.Completed)
                                finished = true
                            }
                        }
                    }
                }
            } catch (e: IOException) {
                val errorType = if (!isNetworkAvailable()) {
                    ClaudeErrorType.OFFLINE
                } else {
                    ClaudeErrorType.NETWORK_ERROR
                }
                emit(
                    SseEvent.Error(
                        errorType,
                        e.localizedMessage ?: "Network connection interrupted."
                    )
                )
                finished = true
            }

            if (shouldRetry429) {
                attempt++
                emit(SseEvent.RateLimitRetry(attempt, retryWaitMs))
                delay(retryWaitMs)
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun parseErrorMessage(rawJson: String, statusCode: Int): String {
        val dto = runCatching {
            json.decodeFromString<ClaudeErrorResponseDto>(rawJson)
        }.getOrNull()
        val detail = dto?.error?.message
        return if (!detail.isNullOrBlank()) {
            "HTTP $statusCode: $detail"
        } else {
            when (statusCode) {
                401, 403 -> "Invalid Anthropic API key (HTTP $statusCode). Please check your API key in Settings."
                429 -> "Rate limit exceeded (HTTP 429). Please wait a moment and retry."
                else -> "Claude API error (HTTP $statusCode)."
            }
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    companion object {
        const val ANTHROPIC_MESSAGES_URL = "https://api.anthropic.com/v1/messages"
        const val ANTHROPIC_VERSION = "2023-06-01"
    }
}
