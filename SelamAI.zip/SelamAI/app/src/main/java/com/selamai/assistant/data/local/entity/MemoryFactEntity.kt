package com.selamai.assistant.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memory_facts")
data class MemoryFactEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val category: String, // Goal, Preference, Habit, General
    val content: String,
    val updatedAt: Long = System.currentTimeMillis()
)
