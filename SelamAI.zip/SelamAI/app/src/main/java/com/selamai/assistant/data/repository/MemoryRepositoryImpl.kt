package com.selamai.assistant.data.repository

import com.selamai.assistant.data.local.dao.MemoryFactDao
import com.selamai.assistant.data.local.entity.MemoryFactEntity
import com.selamai.assistant.domain.model.MemoryFact
import com.selamai.assistant.domain.repository.MemoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryRepositoryImpl @Inject constructor(
    private val memoryFactDao: MemoryFactDao
) : MemoryRepository {

    override fun observeMemoryFacts(): Flow<List<MemoryFact>> {
        return memoryFactDao.observeAllMemoryFacts().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun getAllMemoryFacts(): List<MemoryFact> {
        return memoryFactDao.getAllMemoryFacts().map { it.toDomain() }
    }

    override suspend fun addMemoryFact(category: String, content: String) {
        val cleanContent = content.trim()
        if (cleanContent.isEmpty()) return
        val existing = memoryFactDao.findByContent(cleanContent)
        if (existing != null) {
            memoryFactDao.updateMemoryFact(
                existing.copy(
                    category = category.trim().ifEmpty { "General" },
                    updatedAt = System.currentTimeMillis()
                )
            )
        } else {
            memoryFactDao.insertMemoryFact(
                MemoryFactEntity(
                    category = category.trim().ifEmpty { "General" },
                    content = cleanContent,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    override suspend fun updateMemoryFact(fact: MemoryFact) {
        val cleanContent = fact.content.trim()
        if (cleanContent.isEmpty()) return
        memoryFactDao.updateMemoryFact(
            MemoryFactEntity(
                id = fact.id,
                category = fact.category.trim().ifEmpty { "General" },
                content = cleanContent,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    override suspend fun deleteMemoryFact(id: Long) {
        memoryFactDao.deleteMemoryFactById(id)
    }

    private fun MemoryFactEntity.toDomain() = MemoryFact(
        id = id,
        category = category,
        content = content,
        updatedAt = updatedAt
    )
}
