package com.selamai.assistant.data.repository

import com.selamai.assistant.data.local.dao.ConversationDao
import com.selamai.assistant.data.local.dao.MessageDao
import com.selamai.assistant.data.local.entity.ConversationEntity
import com.selamai.assistant.data.local.entity.MessageEntity
import com.selamai.assistant.data.local.prefs.SecurePrefsManager
import com.selamai.assistant.data.remote.ClaudeSseClient
import com.selamai.assistant.data.remote.SseEvent
import com.selamai.assistant.data.remote.dto.ClaudeContentBlock
import com.selamai.assistant.data.remote.dto.ClaudeInputMessage
import com.selamai.assistant.data.remote.dto.ClaudeMessageRequest
import com.selamai.assistant.domain.model.Conversation
import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.MessageRole
import com.selamai.assistant.domain.model.StreamStatus
import com.selamai.assistant.domain.repository.ChatRepository
import com.selamai.assistant.domain.repository.MemoryRepository
import com.selamai.assistant.util.ImageHelper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val memoryRepository: MemoryRepository,
    private val securePrefsManager: SecurePrefsManager,
    private val claudeSseClient: ClaudeSseClient,
    private val imageHelper: ImageHelper
) : ChatRepository {

    override fun observeConversations(searchQuery: String): Flow<List<Conversation>> {
        val sourceFlow = if (searchQuery.isBlank()) {
            conversationDao.observeAllConversations()
        } else {
            conversationDao.searchConversations(searchQuery.trim())
        }
        return sourceFlow.map { list -> list.map { it.toDomain() } }
    }

    override fun observeMessages(conversationId: Long): Flow<List<Message>> {
        return messageDao.observeMessagesForConversation(conversationId).map { list ->
            list.map { it.toDomain() }
        }
    }

    override suspend fun getMessages(conversationId: Long): List<Message> {
        return messageDao.getMessagesForConversation(conversationId).map { it.toDomain() }
    }

    override suspend fun getConversation(conversationId: Long): Conversation? {
        return conversationDao.getConversationById(conversationId)?.toDomain()
    }

    override suspend fun createConversation(title: String): Long {
        val now = System.currentTimeMillis()
        return conversationDao.insertConversation(
            ConversationEntity(
                title = title.trim().ifEmpty { "አዲስ ውይይት / New Chat" },
                createdAt = now,
                updatedAt = now
            )
        )
    }

    override suspend fun renameConversation(conversationId: Long, newTitle: String) {
        val clean = newTitle.trim()
        if (clean.isNotEmpty()) {
            conversationDao.renameConversation(conversationId, clean)
        }
    }

    override suspend fun deleteConversation(conversationId: Long) {
        conversationDao.deleteConversationById(conversationId)
    }

    override fun sendUserMessageAndStreamReply(
        conversationId: Long,
        userText: String,
        attachedImagePath: String?,
        attachedImageMimeType: String?
    ): Flow<StreamStatus> = flow {
        val existingMessages = messageDao.getMessagesForConversation(conversationId)
        val isFirstUserMessage = existingMessages.isEmpty()

        val userMessageId = messageDao.insertMessage(
            MessageEntity(
                conversationId = conversationId,
                role = MessageRole.USER.apiValue,
                content = userText.trim(),
                imagePath = attachedImagePath,
                imageMimeType = attachedImageMimeType,
                isError = false,
                timestamp = System.currentTimeMillis()
            )
        )

        if (isFirstUserMessage && userText.isNotBlank()) {
            val autoTitle = userText.trim().lineSequence().first().take(42)
            conversationDao.renameConversation(conversationId, autoTitle)
        } else {
            conversationDao.touchConversation(conversationId)
        }

        if (userMessageId > 0) {
            streamAssistantResponseForHistory(conversationId).collect { emit(it) }
        }
    }

    override fun regenerateLastAssistantReply(conversationId: Long): Flow<StreamStatus> = flow {
        val history = messageDao.getMessagesForConversation(conversationId)
        if (history.isEmpty()) return@flow

        val lastMessage = history.last()
        if (lastMessage.role.equals(MessageRole.ASSISTANT.apiValue, ignoreCase = true)) {
            messageDao.deleteMessageById(lastMessage.id)
        }

        val remaining = messageDao.getMessagesForConversation(conversationId)
        if (remaining.isEmpty()) return@flow

        streamAssistantResponseForHistory(conversationId).collect { emit(it) }
    }

    private fun streamAssistantResponseForHistory(conversationId: Long): Flow<StreamStatus> = flow {
        emit(StreamStatus.Streaming(""))

        val history = messageDao.getMessagesForConversation(conversationId)
            .filter { !it.isError }

        val placeholderId = messageDao.insertMessage(
            MessageEntity(
                conversationId = conversationId,
                role = MessageRole.ASSISTANT.apiValue,
                content = "",
                isError = false,
                timestamp = System.currentTimeMillis()
            )
        )

        val systemPromptWithMemory = buildSystemPromptWithMemoryContext()
        val apiMessages = buildClaudeMessages(history)
        val request = ClaudeMessageRequest(
            model = securePrefsManager.getModelName(),
            maxTokens = 4096,
            system = systemPromptWithMemory,
            messages = apiMessages,
            stream = true
        )

        val accumulated = StringBuilder()

        claudeSseClient.streamMessages(
            apiKey = securePrefsManager.getApiKey(),
            requestPayload = request
        ).collect { event ->
            when (event) {
                is SseEvent.TokenDelta -> {
                    accumulated.append(event.text)
                    val visiblePreview = stripMemoryTags(accumulated.toString())
                    messageDao.updateMessageContent(placeholderId, visiblePreview, isError = false)
                    emit(StreamStatus.Streaming(visiblePreview))
                }
                is SseEvent.RateLimitRetry -> {
                    emit(StreamStatus.RetryingRateLimit(event.attempt, event.waitMs))
                }
                is SseEvent.Completed -> {
                    val rawFullText = accumulated.toString()
                    extractAndSaveLearnedMemories(rawFullText)
                    val cleanFinalText = stripMemoryTags(rawFullText).trim()
                    messageDao.updateMessageContent(placeholderId, cleanFinalText, isError = false)
                    conversationDao.touchConversation(conversationId)
                    emit(StreamStatus.Completed)
                }
                is SseEvent.Error -> {
                    val errorContent = if (accumulated.isNotEmpty()) {
                        "${stripMemoryTags(accumulated.toString())}\n\n[${event.message}]"
                    } else {
                        event.message
                    }
                    messageDao.updateMessageContent(placeholderId, errorContent, isError = true)
                    emit(StreamStatus.Error(event.errorType, event.message))
                }
            }
        }
    }

    private suspend fun buildSystemPromptWithMemoryContext(): String {
        val basePrompt = securePrefsManager.getSystemPrompt()
        val memories = memoryRepository.getAllMemoryFacts()

        val memoryBlock = if (memories.isEmpty()) {
            "No personal facts recorded yet."
        } else {
            memories.joinToString(separator = "\n") { fact ->
                "- [${fact.category}] ${fact.content}"
            }
        }

        return buildString {
            append(basePrompt)
            append("\n\n<user_memory>\n")
            append("The following are verified facts about the user (goals, preferences, habits). ")
            append("Include them naturally as context when relevant:\n")
            append(memoryBlock)
            append("\n</user_memory>\n\n")
            append("<memory_instruction>\n")
            append("Whenever the user explicitly shares a new enduring personal fact about themselves ")
            append("(such as their name, occupation, business, goal, preference, or habit), append ")
            append("one tag at the very end of your response using the exact format: ")
            append("[[MEMORY:Category|Fact summary]] where Category is one of Goal, Preference, Habit, or General. ")
            append("Do not emit the tag if no new personal fact was shared.\n")
            append("</memory_instruction>")
        }
    }

    private fun buildClaudeMessages(history: List<MessageEntity>): List<ClaudeInputMessage> {
        return history.mapNotNull { entity ->
            val blocks = mutableListOf<ClaudeContentBlock>()
            if (!entity.imagePath.isNullOrBlank()) {
                val base64 = imageHelper.encodeFileToBase64(entity.imagePath)
                if (!base64.isNullOrBlank()) {
                    blocks.add(
                        ClaudeContentBlock.imageBlock(
                            mediaType = entity.imageMimeType ?: "image/jpeg",
                            base64Data = base64
                        )
                    )
                }
            }

            val textContent = entity.content.trim().ifEmpty {
                if (blocks.isNotEmpty()) "Please describe or help with this attached image." else ""
            }
            if (textContent.isNotEmpty()) {
                blocks.add(ClaudeContentBlock.textBlock(textContent))
            }

            if (blocks.isEmpty()) {
                null
            } else {
                ClaudeInputMessage(
                    role = entity.role,
                    content = blocks
                )
            }
        }
    }

    private suspend fun extractAndSaveLearnedMemories(rawText: String) {
        MEMORY_TAG_REGEX.findAll(rawText).forEach { matchResult ->
            val category = matchResult.groupValues.getOrNull(1)?.trim().orEmpty().ifEmpty { "General" }
            val factContent = matchResult.groupValues.getOrNull(2)?.trim().orEmpty()
            if (factContent.isNotEmpty()) {
                memoryRepository.addMemoryFact(category, factContent)
            }
        }
    }

    private fun stripMemoryTags(rawText: String): String {
        return rawText
            .replace(MEMORY_TAG_REGEX, "")
            .replace(PARTIAL_MEMORY_TAG_REGEX, "")
    }

    private fun ConversationEntity.toDomain() = Conversation(
        id = id,
        title = title,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun MessageEntity.toDomain() = Message(
        id = id,
        conversationId = conversationId,
        role = MessageRole.fromApiValue(role),
        content = content,
        imagePath = imagePath,
        imageMimeType = imageMimeType,
        isError = isError,
        timestamp = timestamp
    )

    companion object {
        private val MEMORY_TAG_REGEX = Regex("""\[\[MEMORY:([^|\]]+)\|([^\]]+)]]""")
        private val PARTIAL_MEMORY_TAG_REGEX = Regex("""\[\[MEMORY:[^\]]*$""")
    }
}
