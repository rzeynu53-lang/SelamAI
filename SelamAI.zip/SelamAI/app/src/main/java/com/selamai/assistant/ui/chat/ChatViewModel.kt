package com.selamai.assistant.ui.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.selamai.assistant.data.local.prefs.SecurePrefsManager
import com.selamai.assistant.domain.model.Conversation
import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.StreamStatus
import com.selamai.assistant.domain.repository.ChatRepository
import com.selamai.assistant.util.ExportHelper
import com.selamai.assistant.util.ImageHelper
import com.selamai.assistant.util.PreparedImage
import com.selamai.assistant.util.VoiceHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val securePrefsManager: SecurePrefsManager,
    private val voiceHelper: VoiceHelper,
    private val imageHelper: ImageHelper,
    private val exportHelper: ExportHelper
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val conversations: StateFlow<List<Conversation>> = _searchQuery
        .flatMapLatest { query -> chatRepository.observeConversations(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeConversationId = MutableStateFlow(0L)
    val activeConversationId: StateFlow<Long> = _activeConversationId.asStateFlow()

    val messages: StateFlow<List<Message>> = _activeConversationId
        .flatMapLatest { id ->
            if (id <= 0L) flowOf(emptyList()) else chatRepository.observeMessages(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _attachedImage = MutableStateFlow<PreparedImage?>(null)
    val attachedImage: StateFlow<PreparedImage?> = _attachedImage.asStateFlow()

    private val _streamStatus = MutableStateFlow<StreamStatus>(StreamStatus.Idle)
    val streamStatus: StateFlow<StreamStatus> = _streamStatus.asStateFlow()

    private val _voiceLocale = MutableStateFlow(securePrefsManager.getVoiceLocale())
    val voiceLocale: StateFlow<String> = _voiceLocale.asStateFlow()

    val isListeningVoice: StateFlow<Boolean> = voiceHelper.isListening
    val isSpeakingTts: StateFlow<Boolean> = voiceHelper.isSpeaking

    private var pendingCameraFile: File? = null
    private var streamJob: Job? = null

    init {
        viewModelScope.launch {
            chatRepository.observeConversations("").collect { list ->
                if (_activeConversationId.value == 0L) {
                    if (list.isNotEmpty()) {
                        _activeConversationId.value = list.first().id
                    } else {
                        val newId = chatRepository.createConversation("አዲስ ውይይት / New Chat")
                        _activeConversationId.value = newId
                    }
                }
            }
        }
    }

    fun isApiKeyConfigured(): Boolean = securePrefsManager.getApiKey().isNotBlank()

    fun onInputTextChange(newText: String) {
        _inputText.value = newText
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun selectConversation(conversationId: Long) {
        _activeConversationId.value = conversationId
        _streamStatus.value = StreamStatus.Idle
    }

    fun createNewConversation() {
        viewModelScope.launch {
            val newId = chatRepository.createConversation("አዲስ ውይይት / New Chat")
            _activeConversationId.value = newId
            _inputText.value = ""
            _attachedImage.value = null
            _streamStatus.value = StreamStatus.Idle
        }
    }

    fun renameConversation(conversationId: Long, newTitle: String) {
        viewModelScope.launch {
            chatRepository.renameConversation(conversationId, newTitle)
        }
    }

    fun deleteConversation(conversationId: Long) {
        viewModelScope.launch {
            chatRepository.deleteConversation(conversationId)
            if (_activeConversationId.value == conversationId) {
                _activeConversationId.value = 0L
            }
        }
    }

    fun onGalleryImagePicked(uri: Uri) {
        viewModelScope.launch {
            val prepared = imageHelper.copyAndCompressUriToInternalStorage(uri)
            if (prepared != null) {
                _attachedImage.value = prepared
            }
        }
    }

    fun prepareCameraCaptureUri(): Uri {
        val (uri, file) = imageHelper.createTempCameraUri()
        pendingCameraFile = file
        return uri
    }

    fun onCameraCaptureSuccess() {
        val file = pendingCameraFile ?: return
        viewModelScope.launch {
            val prepared = imageHelper.compressCameraFileToInternalStorage(file)
            if (prepared != null) {
                _attachedImage.value = prepared
            }
            pendingCameraFile = null
        }
    }

    fun removeAttachedImage() {
        _attachedImage.value = null
    }

    fun sendMessage() {
        val text = _inputText.value.trim()
        val img = _attachedImage.value
        val convoId = _activeConversationId.value
        if (convoId <= 0L || (text.isEmpty() && img == null)) return

        _inputText.value = ""
        _attachedImage.value = null

        streamJob?.cancel()
        streamJob = viewModelScope.launch {
            chatRepository.sendUserMessageAndStreamReply(
                conversationId = convoId,
                userText = text,
                attachedImagePath = img?.localPath,
                attachedImageMimeType = img?.mimeType
            ).collect { status ->
                _streamStatus.value = status
            }
        }
    }

    fun regenerateLastReply() {
        val convoId = _activeConversationId.value
        if (convoId <= 0L) return

        streamJob?.cancel()
        streamJob = viewModelScope.launch {
            chatRepository.regenerateLastAssistantReply(convoId).collect { status ->
                _streamStatus.value = status
            }
        }
    }

    fun toggleVoiceLocale() {
        val next = if (_voiceLocale.value == "am-ET") "en-US" else "am-ET"
        _voiceLocale.value = next
        securePrefsManager.setVoiceLocale(next)
    }

    fun toggleVoiceInput() {
        if (isListeningVoice.value) {
            voiceHelper.stopListening()
        } else {
            voiceHelper.startListening(_voiceLocale.value) { recognizedText ->
                val current = _inputText.value
                _inputText.value = if (current.isBlank()) {
                    recognizedText
                } else {
                    "$current $recognizedText"
                }
            }
        }
    }

    fun toggleReadAloud(text: String) {
        voiceHelper.speakText(text)
    }

    fun exportCurrentConversation(onEmpty: () -> Unit) {
        val convoId = _activeConversationId.value
        if (convoId <= 0L) {
            onEmpty()
            return
        }
        viewModelScope.launch {
            val conversation = chatRepository.getConversation(convoId) ?: return@launch
            val convoMessages = chatRepository.getMessages(convoId)
            if (convoMessages.isEmpty()) {
                onEmpty()
                return@launch
            }
            val file = exportHelper.exportConversationToTextFile(conversation, convoMessages)
            exportHelper.shareExportedFile(file)
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceHelper.shutdown()
    }
}
