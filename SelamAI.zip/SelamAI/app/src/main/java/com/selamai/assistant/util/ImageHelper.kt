package com.selamai.assistant.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.core.content.FileProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

data class PreparedImage(
    val localPath: String,
    val mimeType: String
)

@Singleton
class ImageHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun createTempCameraUri(): Pair<Uri, File> {
        val cameraDir = File(context.cacheDir, "camera").apply { mkdirs() }
        val photoFile = File(cameraDir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            photoFile
        )
        return uri to photoFile
    }

    fun copyAndCompressUriToInternalStorage(uri: Uri): PreparedImage? {
        return runCatching {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val originalBitmap = inputStream.use { BitmapFactory.decodeStream(it) } ?: return null
            val scaledBitmap = scaleDownBitmap(originalBitmap, MAX_IMAGE_DIMENSION)

            val imagesDir = File(context.filesDir, "attachments").apply { mkdirs() }
            val destFile = File(imagesDir, "img_${System.currentTimeMillis()}.jpg")
            FileOutputStream(destFile).use { out ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            }
            PreparedImage(
                localPath = destFile.absolutePath,
                mimeType = "image/jpeg"
            )
        }.getOrNull()
    }

    fun compressCameraFileToInternalStorage(cameraFile: File): PreparedImage? {
        if (!cameraFile.exists()) return null
        return runCatching {
            val originalBitmap = BitmapFactory.decodeFile(cameraFile.absolutePath) ?: return null
            val scaledBitmap = scaleDownBitmap(originalBitmap, MAX_IMAGE_DIMENSION)

            val imagesDir = File(context.filesDir, "attachments").apply { mkdirs() }
            val destFile = File(imagesDir, "cam_${System.currentTimeMillis()}.jpg")
            FileOutputStream(destFile).use { out ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            }
            cameraFile.delete()
            PreparedImage(
                localPath = destFile.absolutePath,
                mimeType = "image/jpeg"
            )
        }.getOrNull()
    }

    fun encodeFileToBase64(path: String): String? {
        val file = File(path)
        if (!file.exists()) return null
        return runCatching {
            val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return null
            val scaled = scaleDownBitmap(bitmap, MAX_IMAGE_DIMENSION)
            val output = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 85, output)
            Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        }.getOrNull()
    }

    private fun scaleDownBitmap(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap

        val ratio = width.toFloat() / height.toFloat()
        val newWidth: Int
        val newHeight: Int
        if (width > height) {
            newWidth = maxDimension
            newHeight = (maxDimension / ratio).toInt().coerceAtLeast(1)
        } else {
            newHeight = maxDimension
            newWidth = (maxDimension * ratio).toInt().coerceAtLeast(1)
        }
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }

    companion object {
        private const val MAX_IMAGE_DIMENSION = 1280
    }
}
