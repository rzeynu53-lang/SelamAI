package com.selamai.assistant.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.selamai.assistant.data.local.entity.MemoryFactEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryFactDao {

    @Query("SELECT * FROM memory_facts ORDER BY updatedAt DESC")
    fun observeAllMemoryFacts(): Flow<List<MemoryFactEntity>>

    @Query("SELECT * FROM memory_facts ORDER BY updatedAt DESC")
    suspend fun getAllMemoryFacts(): List<MemoryFactEntity>

    @Query("SELECT * FROM memory_facts WHERE LOWER(content) = LOWER(:content) LIMIT 1")
    suspend fun findByContent(content: String): MemoryFactEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemoryFact(fact: MemoryFactEntity): Long

    @Update
    suspend fun updateMemoryFact(fact: MemoryFactEntity)

    @Query("DELETE FROM memory_facts WHERE id = :id")
    suspend fun deleteMemoryFactById(id: Long)
}
