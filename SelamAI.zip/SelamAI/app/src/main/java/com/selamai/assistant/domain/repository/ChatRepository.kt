package com.selamai.assistant.domain.repository

import com.selamai.assistant.domain.model.Conversation
import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.StreamStatus
import kotlinx.coroutines.flow.Flow

interface ChatRepository {
    fun observeConversations(searchQuery: String = ""): Flow<List<Conversation>>
    fun observeMessages(conversationId: Long): Flow<List<Message>>
    suspend fun getMessages(conversationId: Long): List<Message>
    suspend fun getConversation(conversationId: Long): Conversation?
    suspend fun createConversation(title: String): Long
    suspend fun renameConversation(conversationId: Long, newTitle: String)
    suspend fun deleteConversation(conversationId: Long)

    fun sendUserMessageAndStreamReply(
        conversationId: Long,
        userText: String,
        attachedImagePath: String? = null,
        attachedImageMimeType: String? = null
    ): Flow<StreamStatus>

    fun regenerateLastAssistantReply(conversationId: Long): Flow<StreamStatus>
}
