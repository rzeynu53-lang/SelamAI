package com.selamai.assistant.data.local.prefs

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.selamai.assistant.ui.theme.ThemeMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SecurePrefsManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val encryptedPrefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Fallback only if hardware keystore gets corrupted on device reset
            context.deleteSharedPreferences(PREFS_FILE_NAME)
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
    }

    private val _themeModeFlow = MutableStateFlow(getThemeMode())
    val themeModeFlow: StateFlow<ThemeMode> = _themeModeFlow.asStateFlow()

    private val _appLanguageFlow = MutableStateFlow(getAppLanguage())
    val appLanguageFlow: StateFlow<String> = _appLanguageFlow.asStateFlow()

    fun getApiKey(): String {
        return encryptedPrefs.getString(KEY_ANTHROPIC_API_KEY, "")?.trim() ?: ""
    }

    fun setApiKey(apiKey: String) {
        encryptedPrefs.edit().putString(KEY_ANTHROPIC_API_KEY, apiKey.trim()).apply()
    }

    fun getModelName(): String {
        return encryptedPrefs.getString(KEY_MODEL_NAME, DEFAULT_MODEL_NAME)
            ?.takeIf { it.isNotBlank() } ?: DEFAULT_MODEL_NAME
    }

    fun setModelName(model: String) {
        encryptedPrefs.edit().putString(
            KEY_MODEL_NAME,
            model.trim().ifBlank { DEFAULT_MODEL_NAME }
        ).apply()
    }

    fun getSystemPrompt(): String {
        return encryptedPrefs.getString(KEY_SYSTEM_PROMPT, DEFAULT_SYSTEM_PROMPT)
            ?.takeIf { it.isNotBlank() } ?: DEFAULT_SYSTEM_PROMPT
    }

    fun setSystemPrompt(prompt: String) {
        encryptedPrefs.edit().putString(
            KEY_SYSTEM_PROMPT,
            prompt.trim().ifBlank { DEFAULT_SYSTEM_PROMPT }
        ).apply()
    }

    fun getThemeMode(): ThemeMode {
        val raw = encryptedPrefs.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name)
        return runCatching { ThemeMode.valueOf(raw ?: ThemeMode.SYSTEM.name) }
            .getOrDefault(ThemeMode.SYSTEM)
    }

    fun setThemeMode(mode: ThemeMode) {
        encryptedPrefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        _themeModeFlow.value = mode
    }

    fun getAppLanguage(): String {
        return encryptedPrefs.getString(KEY_APP_LANGUAGE, "am") ?: "am"
    }

    fun setAppLanguage(langCode: String) {
        encryptedPrefs.edit().putString(KEY_APP_LANGUAGE, langCode).apply()
        _appLanguageFlow.value = langCode
    }

    fun getVoiceLocale(): String {
        return encryptedPrefs.getString(KEY_VOICE_LOCALE, "am-ET") ?: "am-ET"
    }

    fun setVoiceLocale(localeTag: String) {
        encryptedPrefs.edit().putString(KEY_VOICE_LOCALE, localeTag).apply()
    }

    companion object {
        private const val PREFS_FILE_NAME = "selam_ai_secure_prefs"
        private const val KEY_ANTHROPIC_API_KEY = "anthropic_api_key"
        private const val KEY_MODEL_NAME = "claude_model_name"
        private const val KEY_SYSTEM_PROMPT = "system_prompt"
        private const val KEY_THEME_MODE = "theme_mode"
        private const val KEY_APP_LANGUAGE = "app_language"
        private const val KEY_VOICE_LOCALE = "voice_locale"

        const val DEFAULT_MODEL_NAME = "claude-sonnet-5-5"
        const val DEFAULT_SYSTEM_PROMPT =
            "You are a concise, warm, direct personal AI assistant fluent in Amharic (አማርኛ) and English. " +
                "Always reply in the language the user writes in. Use the provided personal memory facts naturally to personalize your help."
    }
}
