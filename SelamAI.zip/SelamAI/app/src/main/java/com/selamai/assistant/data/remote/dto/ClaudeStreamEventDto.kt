package com.selamai.assistant.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ClaudeStreamEventDto(
    val type: String,
    val index: Int? = null,
    val delta: ClaudeDeltaDto? = null,
    val error: ClaudeErrorDetailDto? = null
)

@Serializable
data class ClaudeDeltaDto(
    val type: String? = null,
    val text: String? = null,
    @SerialName("stop_reason")
    val stopReason: String? = null
)

@Serializable
data class ClaudeErrorResponseDto(
    val type: String? = null,
    val error: ClaudeErrorDetailDto? = null
)

@Serializable
data class ClaudeErrorDetailDto(
    val type: String? = null,
    val message: String? = null
)
