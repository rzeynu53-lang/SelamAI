package com.selamai.assistant.ui.memory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.selamai.assistant.domain.model.MemoryFact
import com.selamai.assistant.domain.repository.MemoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MemoryViewModel @Inject constructor(
    private val memoryRepository: MemoryRepository
) : ViewModel() {

    val memoryFacts: StateFlow<List<MemoryFact>> = memoryRepository
        .observeMemoryFacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addFact(category: String, content: String) {
        viewModelScope.launch {
            memoryRepository.addMemoryFact(category, content)
        }
    }

    fun updateFact(fact: MemoryFact, newCategory: String, newContent: String) {
        viewModelScope.launch {
            memoryRepository.updateMemoryFact(
                fact.copy(
                    category = newCategory,
                    content = newContent
                )
            )
        }
    }

    fun deleteFact(id: Long) {
        viewModelScope.launch {
            memoryRepository.deleteMemoryFact(id)
        }
    }
}
