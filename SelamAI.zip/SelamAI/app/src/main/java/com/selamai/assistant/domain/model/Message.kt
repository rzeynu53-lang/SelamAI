package com.selamai.assistant.domain.model

data class Message(
    val id: Long = 0L,
    val conversationId: Long,
    val role: MessageRole,
    val content: String,
    val imagePath: String? = null,
    val imageMimeType: String? = null,
    val isError: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

enum class MessageRole(val apiValue: String) {
    USER("user"),
    ASSISTANT("assistant");

    companion object {
        fun fromApiValue(value: String): MessageRole {
            return if (value.equals("assistant", ignoreCase = true)) ASSISTANT else USER
        }
    }
}
